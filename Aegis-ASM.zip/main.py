from bot.bot import run
run()
